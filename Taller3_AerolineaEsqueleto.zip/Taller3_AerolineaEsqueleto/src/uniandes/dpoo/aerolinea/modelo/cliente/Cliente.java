package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	

	
	
	public Cliente() {
		this.tiquetesSinUsar = new ArrayList<>();
		this.tiquetesUsados = new ArrayList<>();
	}




	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	
	public void agregarTiquete​( Tiquete tiquete ) 
	{
		tiquetesSinUsar.add(tiquete);
	}
	
	public int calcularValorTotalTiquetes()
	{
		int total = 0;
		
		for (int i = 0; i < tiquetesSinUsar.size(); i++) {
			total += tiquetesSinUsar.get(i).getTarifa();
		}
		
		for (int i = 0; i < tiquetesUsados.size(); i++) {
			
			total += tiquetesUsados.get(i).getTarifa();
		}
		
		return total;
		
	}
	
	
	public void usarTiquetes​( Vuelo vuelo ) 
	{
		//Aquí debo usar while ya que como voy a modificar la lista los for no sirven
		
		int i = 0;
		
		while (i < tiquetesSinUsar.size()) {
			
			Tiquete t = tiquetesSinUsar.get(i);
			
			if (t.getVuelo().equals(vuelo)) {
				
				t.marcarComoUsado();
				tiquetesUsados.add(t);
				tiquetesSinUsar.remove(i);
			}
			
			else {
				i++;
			}
			
			
		}
		
		
	}
	
	
	
	
}
