package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	
	public double IMPUESTO = 0.28;
	
	
	
	public CalculadoraTarifas() {
	}

	public int calcularTarifa (Vuelo vuelo, Cliente cliente)
	{
		int costoBase = calcularCostoBase(vuelo, cliente);
		
		double descuento = calcularPorcentajeDescuento(cliente);
		
		int costo = (int) (costoBase - descuento);
		
		int impuesto = calcularValorImpuesto(costo);
				
		int costoImpuesto = impuesto + costo; 
		
		return costoImpuesto;
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int distanciaVuelo(Ruta ruta)
	{
		Aeropuerto origen = ruta.getOrigen();
		Aeropuerto destino = ruta.getDestino();
		
		return Aeropuerto.calcularDistancia(origen, destino);
		
		
	}
	
	protected int calcularValorImpuesto(int costoBase)
	{
		return (int)Math.round(costoBase * IMPUESTO);
	}

}
