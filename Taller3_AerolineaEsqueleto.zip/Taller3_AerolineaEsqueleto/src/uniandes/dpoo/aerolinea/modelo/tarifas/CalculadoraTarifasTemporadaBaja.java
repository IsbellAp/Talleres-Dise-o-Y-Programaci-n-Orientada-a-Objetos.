package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {

	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_GRANDES = 0.2;
	
	
	
	
	
	public CalculadoraTarifasTemporadaBaja() {
		super();
	}
	
	
	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		
		int distancia = distanciaVuelo(vuelo.getRuta());
		
		
		if (cliente.getTipoCliente().equals("Corporativo"))
		{
			return COSTO_POR_KM_CORPORATIVO * distancia;
			
		}
		
		else
		{
			return COSTO_POR_KM_NATURAL * distancia;
		}
		
		
	}
	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
		
		if(cliente.getTipoCliente().equals("Corporativo"))
		{
			ClienteCorporativo corp = (ClienteCorporativo) cliente; 
			
			if(corp.getTamanoEmpresa() == 1)
			{
				return DESCUENTO_GRANDES;
			}
			
			if(corp.getTamanoEmpresa() == 2)
			{
				return DESCUENTO_MEDIANAS;
			}
			
			if (corp.getTamanoEmpresa() == 3)
			{
				return DESCUENTO_PEQ;
			}
			
		}
		
		return 0;
	}
	
	
	
	
	
}
