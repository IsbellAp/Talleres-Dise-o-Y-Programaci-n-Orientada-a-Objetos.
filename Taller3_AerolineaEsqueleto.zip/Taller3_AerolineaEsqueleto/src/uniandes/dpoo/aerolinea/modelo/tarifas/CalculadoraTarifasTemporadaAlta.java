package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;



public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas {
	
	protected final int COSTO_POR_KM = 1000;
	
	public CalculadoraTarifasTemporadaAlta() {
		
	}
	

	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		int distancia = distanciaVuelo(vuelo.getRuta());
		return COSTO_POR_KM * distancia;
	}

	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
		return 0; //Es que como acá no tenemos las variables dependiendo el descuento por tipo de cliente, asumo que no hay descuentos
	}
	
	

	
	
}
