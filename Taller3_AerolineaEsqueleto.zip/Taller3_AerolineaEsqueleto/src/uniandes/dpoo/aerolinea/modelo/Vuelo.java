package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	
	private Avion avion;
	private String fecha;
	private Ruta ruta;
	private Map<String, Tiquete> tiquetes;
	
	public Vuelo(Avion avion, String fecha, Ruta ruta) {
		this.avion = avion;
		this.fecha = fecha;
		this.ruta = ruta;
		this.tiquetes = new HashMap <String, Tiquete>();
	}

	public Avion getAvion() {
		return avion;
	}

	public void setAvion(Avion avion) {
		this.avion = avion;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Ruta getRuta() {
		return ruta;
	}

	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}

	public Collection<Tiquete> getTiquetes() {
		return tiquetes.values();
	}

	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad)
	
		throws VueloSobrevendidoException
		
		{
			int capacidad = avion.getCapacidad();
			int vendidos = tiquetes.size();
			
			if (vendidos + cantidad > capacidad)
			{
				throw new VueloSobrevendidoException(this);
				
			}
			
			int tarifaPorTiquete = calculadora.calcularTarifa(this, cliente);
			int total = tarifaPorTiquete * cantidad;
			
			for (int i = 0; i < cantidad; i++) {
				
				Tiquete nuevo = GeneradorTiquetes.generarTiquete(this, cliente, tarifaPorTiquete);
				
				tiquetes.put(nuevo.getCodigo(), nuevo);
				cliente.agregarTiquete​(nuevo);
				GeneradorTiquetes.registrarTiquete(nuevo);
				
				
			}
			return total;
		
		
		
		}

	@Override
	public boolean equals(Object obj) {

		
		// this.equals(obj) teniendo en cuenta esto la idea es saber si el vuelo corresponde a la ruta y a la fecha, creo
	    if (this == obj)
	        return true;

	    if (obj == null)
	        return false;

	    if (getClass() != obj.getClass())
	        return false;

	    Vuelo other = (Vuelo) obj;

	    if (!fecha.equals(other.fecha)) //SI SON DIFERENTES
	        return false;

	    if (!ruta.equals(other.ruta)) // SI SON DIFERENTES
	        return false;

	    return true;
	}
	
	
	
	
	
	
	

}
