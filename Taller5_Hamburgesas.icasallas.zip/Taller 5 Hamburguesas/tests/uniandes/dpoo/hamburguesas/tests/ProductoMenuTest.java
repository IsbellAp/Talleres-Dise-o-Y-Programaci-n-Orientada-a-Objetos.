package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {

	// Una clase de JUnit no necesita constructor. JUnit crea los objetos automaticamente
	private ProductoMenu productoNormal;
    private ProductoMenu productoCostoso;
    private ProductoMenu productoGratis;
    private ProductoMenu productoNombreVacio;
	 
    @BeforeEach
    void setUp() {
        productoNormal = new ProductoMenu("Hamburguesa", 15000);
        productoCostoso = new ProductoMenu("Combo Premium", 50000);
        productoGratis = new ProductoMenu("Agua", 0);
        productoNombreVacio = new ProductoMenu("", 5000);
    }
	
	
    @Test
    void testGetNombre() {
        assertEquals("Hamburguesa", productoNormal.getNombre());
        assertEquals("Combo Premium", productoCostoso.getNombre());
        assertEquals("Agua", productoGratis.getNombre());
        assertEquals("", productoNombreVacio.getNombre());
    }

    @Test
    void testGetPrecio() {
        assertEquals(15000, productoNormal.getPrecio());
        assertEquals(50000, productoCostoso.getPrecio());
        assertEquals(0, productoGratis.getPrecio());
        assertEquals(5000, productoNombreVacio.getPrecio());
    }

    @Test
    void testGenerarTextoFactura() {
        assertEquals("Hamburguesa\n" + "            15000\n", productoNormal.generarTextoFactura());
        assertEquals("Combo Premium\n" + "            50000\n", productoCostoso.generarTextoFactura());
        assertEquals("Agua\n" + "            0\n", productoGratis.generarTextoFactura());
        assertEquals("\n" + "            5000\n", productoNombreVacio.generarTextoFactura());
    }
}

