package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

import java.io.File;


public class RestauranteTest {

    private Restaurante restaurante;

    //Aqui utilizo archivos reales de la descarga original para testear lo que es getters, setters, etc.
    private File archivoIngredientes = new File("./data/ingredientes.txt");
    private File archivoMenu         = new File("./data/menu.txt");
    private File archivoCombos       = new File("./data/combos.txt");

    @BeforeEach
    void setUp() {
        restaurante = new Restaurante();
       
    }
    
    //Empiezo con getters
    
    
    @Test
    void testGetIngredientesAntesDeCargar() {
        assertNotNull(restaurante.getIngredientes());
        assertEquals(0, restaurante.getIngredientes().size());
    }

    @Test
    void testGetIngredientesDespuesDeCargar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNotNull(restaurante.getIngredientes());
        assertEquals(15, restaurante.getIngredientes().size());
    }


    @Test
    void testGetMenuBaseAntesDeCargar() {
        assertNotNull(restaurante.getMenuBase());
        assertEquals(0, restaurante.getMenuBase().size());
    }

    @Test
    void testGetMenuBaseDespuesDeCargar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNotNull(restaurante.getMenuBase());
        assertEquals(22, restaurante.getMenuBase().size());
    }

    @Test
    void testGetMenuCombosAntesDeCargar() {
        assertNotNull(restaurante.getMenuCombos());
        assertEquals(0, restaurante.getMenuCombos().size());
    }

    @Test
    void testGetMenuCombosDespuesDeCargar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNotNull(restaurante.getMenuCombos());
        assertEquals(4, restaurante.getMenuCombos().size());
    }


    @Test
    void testGetPedidosInicialmenteVacio() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNotNull(restaurante.getPedidos());
        assertEquals(0, restaurante.getPedidos().size());
    }

    @Test
    void testGetPedidos_despuesDeCerrarTres_tienesTres() throws Exception {
        new File("./facturas/").mkdirs();
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);

        restaurante.iniciarPedido("Cliente 1", "ej 1"); //Si, me dió pereza inventarme direcciones
        restaurante.cerrarYGuardarPedido();
        restaurante.iniciarPedido("Cliente 2", "ej 2");
        restaurante.cerrarYGuardarPedido();
        restaurante.iniciarPedido("Cliente 3", "ej 3");
        restaurante.cerrarYGuardarPedido();

        assertEquals(3, restaurante.getPedidos().size());
    }

   

    @Test
    void testGetPedidoEnCursoSinIniciar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNull(restaurante.getPedidoEnCurso());
    }

    @Test
    void testGetPedidoEnCursoDespuesDeIniciar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        restaurante.iniciarPedido("María García", "Calle 10");
        assertNotNull(restaurante.getPedidoEnCurso());
    }

    @Test
    void testGetPedidoEnCursoDespuesDeCerrar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        restaurante.iniciarPedido("Carlos López", "Carrera 7");
        restaurante.cerrarYGuardarPedido();

        assertNull(restaurante.getPedidoEnCurso());
    }


    //Cargo datos y testeo. Hago uno por uno para testear cada excepcion. 

    @Test
    void testCargaIngredientesCorrectamente() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertEquals(15, restaurante.getIngredientes().size());
    }

    @Test
    void testCargarMenuBaseCorrectamente() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertEquals(22, restaurante.getMenuBase().size());
    }

    @Test
    void testCargarCombosCorrectamente() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertEquals(4, restaurante.getMenuCombos().size());
    }
    
    
    //ESTO ES MUY COMPLICADO. Pero lo tengo que anotar para estudiarlo. 
    //Si bien estos test podría hacerlos con un try, parece mas facil hacerlo con AssertThows 
    //El tema es que este usa () ->  
    //Entonces, el test solo testea lo que este dentro del -> 
    //(Clase_de_excepcion.class, () -> objeto.metodo());
    //Si tira la excepcion, pasa
    //Si no la tira, el test falla
    //De forma similar funciona con el NotAssertThrows

    @Test
    void testCargarIngredienteRepetidoLanzaExcepcion() throws Exception {
        // Cree txt que estan mal para testear cada excepcion
        File archivoAux = new File("./data/ingredientes_repetido.txt");
        assertThrows(IngredienteRepetidoException.class,
                () -> restaurante.cargarInformacionRestaurante(archivoAux, archivoMenu, archivoCombos));
    }

    @Test
    void testCargarProductoRepetidoEnMenuLanzaExcepcion() throws Exception {
        File archivoAux = new File("./data/menu_repetido.txt");
        assertThrows(ProductoRepetidoException.class,
                () -> restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoAux, archivoCombos));
    }

    @Test
    void testCargarComboConProductoInexistenteLanzaExcepcion() throws Exception {
        File archivoAux = new File("./data/combos_mal.txt");
        assertThrows(ProductoFaltanteException.class,
                () -> restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoAux));
    }

    
    @Test
    void testIniciarPedidoCreaElPedidoCorrectamente() throws Exception {
    	//Con los archivos biennn
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        restaurante.iniciarPedido("María García", "Calle 10 # 5-20");

        assertNotNull(restaurante.getPedidoEnCurso());
        assertEquals("María García", restaurante.getPedidoEnCurso().getNombreCliente());
    }

    @Test
    void testIniciarPedidoSinPedidoAntes() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertNull(restaurante.getPedidoEnCurso());
    }

    
    // No inicia otro pedido ya que tenemos un pedido en curso 
    @Test
    void testIniciarPedidoConPedidoEnCursoLanzaExcepcion() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        restaurante.iniciarPedido("Carlos López", "Carrera 7");

        assertThrows(YaHayUnPedidoEnCursoException.class,
                () -> restaurante.iniciarPedido("Ana Martínez", "Av 68"));
    }

    //Esto tambien me costo un montónnn *Estudiarlo para el parcial*
    @Test
    void testCerrarPedidoSinPedidoEnCursoLanzaExcepcion() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        assertThrows(NoHayPedidoEnCursoException.class,
                () -> restaurante.cerrarYGuardarPedido());
    }

    @Test
    void testCerrarPedidoQuedaEnCarpeta() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        restaurante.iniciarPedido("Luis Rodríguez", "Calle 100");

        restaurante.cerrarYGuardarPedido();

        assertNull(restaurante.getPedidoEnCurso());
        assertEquals(1, restaurante.getPedidos().size());
    }

    @Test
    void testCerrarPedidoVariosClientes() throws Exception {
       
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);

        restaurante.iniciarPedido("Cliente 1", "ej 1");
        restaurante.cerrarYGuardarPedido();

        restaurante.iniciarPedido("Cliente 2", "ej 2");
        restaurante.cerrarYGuardarPedido();

        restaurante.iniciarPedido("Cliente 3", "ej 3");
        restaurante.cerrarYGuardarPedido();

        assertEquals(3, restaurante.getPedidos().size());
    }

    @Test
    void testCerrarPedidoDespuesDeCerrar() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);

        restaurante.iniciarPedido("Cliente 1", "ej 1");
        restaurante.cerrarYGuardarPedido();

        // Esto no debe lanzar excepción
        restaurante.iniciarPedido("Cliente 2", "ej 2");
        assertEquals("Cliente 2", restaurante.getPedidoEnCurso().getNombreCliente());
    }
    
    
    
}
