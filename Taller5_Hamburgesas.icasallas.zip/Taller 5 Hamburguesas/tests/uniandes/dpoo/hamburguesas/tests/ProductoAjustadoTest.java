package uniandes.dpoo.hamburguesas.tests;
 
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
 
public class ProductoAjustadoTest {
 
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

 
    private Ingrediente queso;      
    private Ingrediente tocineta;   
    private Ingrediente lechuga;     
    private Ingrediente tomate;      
 
// Escenarios
    private ProductoAjustado ajustadoSinCambios;
    private ProductoAjustado ajustadoSoloAgrega;
    private ProductoAjustado ajustadoSoloElimina;
    private ProductoAjustado ajustadoAgregaYElimina;
    private ProductoAjustado ajustadoAgregaRepetido;
    private ProductoAjustado ajustadoOtroProducto;
 
    @BeforeEach
    void setUp() {
        hamburguesa = new ProductoMenu("corral", 14000);
        papas       = new ProductoMenu("Papas medianas", 5500);

        queso    = new Ingrediente("queso mozzarella", 2500);
        tocineta = new Ingrediente("tocineta picada", 6000);
        lechuga  = new Ingrediente("lechuga", 1000);
        tomate   = new Ingrediente("tomate", 1000);
        
        
        //1
        ajustadoSinCambios = new ProductoAjustado(hamburguesa);
 
        //2
        ajustadoSoloAgrega = new ProductoAjustado(hamburguesa);
        ajustadoSoloAgrega.getAgregados().add(queso);
        ajustadoSoloAgrega.getAgregados().add(tocineta);
 
        //3
        ajustadoSoloElimina = new ProductoAjustado(hamburguesa);
        ajustadoSoloElimina.getEliminados().add(lechuga);
        ajustadoSoloElimina.getEliminados().add(tomate);
 
        //4
        ajustadoAgregaYElimina = new ProductoAjustado(hamburguesa);
        ajustadoAgregaYElimina.getAgregados().add(queso);
        ajustadoAgregaYElimina.getEliminados().add(lechuga);
 
        //5
        ajustadoAgregaRepetido = new ProductoAjustado(hamburguesa);
        ajustadoAgregaRepetido.getAgregados().add(queso);
        ajustadoAgregaRepetido.getAgregados().add(queso);
 
        //6
        ajustadoOtroProducto = new ProductoAjustado(papas);
        ajustadoOtroProducto.getAgregados().add(tocineta);
    }
 
    
    @Test
    void testGetNombreDevuelveNombreDelProductoBase() {
        assertEquals("corral", ajustadoSinCambios.getNombre());
    }
    
 
    @Test
    void testGetNombreOtroProductoBase() {
        assertEquals("Papas medianas", ajustadoOtroProducto.getNombre());
    }
 
 
    @Test
    void testGetPrecioSinCambios() {
        assertEquals(14000, ajustadoSinCambios.getPrecio());
    }
 
    @Test
    void testGetPrecioSoloAgrega() {
        // solo suma
        assertEquals(22500, ajustadoSoloAgrega.getPrecio());
    }
 
    @Test
    void testGetPrecioSoloElimina() {
        // no baja el precio
        assertEquals(14000, ajustadoSoloElimina.getPrecio());
    }
 
    @Test
    void testGetPrecioAgregaYElimina() {
        // Solo suma agregados
        assertEquals(16500, ajustadoAgregaYElimina.getPrecio());
    }
 
    @Test
    void testGetPrecioIgredienteAgregadoDosVeces() {
        assertEquals(19000, ajustadoAgregaRepetido.getPrecio());
    }
 
    @Test
    void testGetPrecioOtroProductoBase() {
        assertEquals(11500, ajustadoOtroProducto.getPrecio());
    }
 
    @Test
    void testGetPrecioProductoConPrecioEnCero() {
        ProductoMenu gratis = new ProductoMenu("Agua gratis", 0);
        ProductoAjustado ajustado = new ProductoAjustado(gratis);
        ajustado.getAgregados().add(queso);
        assertEquals(2500, ajustado.getPrecio());
    }
    
    
    
    ///// nombre normal con \n y espacios como en el test de Producto menu
    // 4 espacios + ingredicntes agregados
    // 16 espacios + precio adicional
    // 4 espacios - ingrediente eliminado
    // 12 espacios +precio eliminado (usualmente 0 o vacío) \n 
    
    
    @Test
    void testGenerarTextoFacturaSinCambios() {
        String esperado = "corral\n" + "            14000\n" + "            14000\n";
        assertEquals(esperado, ajustadoSinCambios.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaSoloAgrega() {
        String esperado = "corral\n" + "            14000\n"  + "    +queso mozzarella" + "                2500" + "    +tocineta picada"  + "                6000" + "            22500\n";
        assertEquals(esperado, ajustadoSoloAgrega.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaSoloElimina() {
        String esperado = "corral\n" + "            14000\n"  + "    -lechuga" + "    -tomate"  + "            14000\n";
        assertEquals(esperado, ajustadoSoloElimina.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaAgregaYElimina() {
        String esperado = "corral\n" + "            14000\n"  + "    +queso mozzarella"  + "                2500" + "    -lechuga" + "            16500\n";
        assertEquals(esperado, ajustadoAgregaYElimina.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaIngredienteRepetido() {
        String esperado = "corral\n" + "            14000\n"  + "    +queso mozzarella"  + "                2500" + "    +queso mozzarella"  + "                2500" + "            19000\n";
        assertEquals(esperado, ajustadoAgregaRepetido.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaOtroProductoBase() {
        String esperado = "Papas medianas\n" + "            5500\n" + "    +tocineta picada" + "                6000" + "            11500\n";
        assertEquals(esperado, ajustadoOtroProducto.generarTextoFactura());
    }
    
}
