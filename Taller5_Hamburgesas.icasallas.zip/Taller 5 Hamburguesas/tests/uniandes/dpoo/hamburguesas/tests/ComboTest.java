package uniandes.dpoo.hamburguesas.tests;
 
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
 
import java.util.ArrayList;
 
public class ComboTest {
 
    //Utilizo de producto ajustado pq me quede sin ideas xd
    private ProductoMenu corral;          
    private ProductoMenu papasMedianas;   
    private ProductoMenu gaseosa;         
    private ProductoMenu todoterreno;     
    private ProductoMenu papasGrandes;    
 
    private Combo comboCorral;         // 10% descuento- 3 items
    private Combo comboTodoterreno;    // 7%  descuento- 3 items
    private Combo comboDosItems;       // 15% descuento- 2 items
    private Combo comboSinDescuento;   // 0%  descuento
    private Combo comboDescuentoTotal; // 100% descuento
    private Combo comboUnItem;         // 1 solo item
 
    @BeforeEach
    void setUp() {
        corral        = new ProductoMenu("corral",        14000);
        papasMedianas = new ProductoMenu("papas medianas", 5500);
        gaseosa       = new ProductoMenu("gaseosa",        5000);
        todoterreno   = new ProductoMenu("todoterreno",   25000);
        papasGrandes  = new ProductoMenu("papas grandes",  6900);
 
        
        ArrayList<ProductoMenu> itemsCorral = new ArrayList<>();
        itemsCorral.add(corral);
        itemsCorral.add(papasMedianas);
        itemsCorral.add(gaseosa);
        comboCorral = new Combo("combo corral", 0.10, itemsCorral);
 
        
        ArrayList<ProductoMenu> itemsTodo = new ArrayList<>();
        itemsTodo.add(todoterreno);
        itemsTodo.add(papasGrandes);
        itemsTodo.add(gaseosa);
        comboTodoterreno = new Combo("combo todoterreno", 0.07, itemsTodo);
 
       
        ArrayList<ProductoMenu> itemsDos = new ArrayList<>();
        itemsDos.add(corral);
        itemsDos.add(papasGrandes);
        comboDosItems = new Combo("combo dos items", 0.15, itemsDos);
 
        
        ArrayList<ProductoMenu> itemsSin = new ArrayList<>();
        itemsSin.add(corral);
        itemsSin.add(papasMedianas);
        comboSinDescuento = new Combo("combo sin descuento", 0.0, itemsSin);
 
       
        ArrayList<ProductoMenu> itemsTotal = new ArrayList<>();
        itemsTotal.add(corral);
        comboDescuentoTotal = new Combo("combo gratis", 1.0, itemsTotal);
 
        
        ArrayList<ProductoMenu> itemsUno = new ArrayList<>();
        itemsUno.add(gaseosa);
        comboUnItem = new Combo("combo gaseosa", 0.10, itemsUno);
    }
 

    @Test
    void testGetNombreComboCorral() {
        assertEquals("combo corral", comboCorral.getNombre());
    }
 
    @Test
    void testGetNombreComboTodoterreno() {
        assertEquals("combo todoterreno", comboTodoterreno.getNombre());
    }
 
    
    // Descrubrí que puedo testear varioa a la vez y ya KNDKJFNSKJDNFJKSDNF
    @Test
    void testGetNombreVariosNombres() {
        assertEquals("combo dos items",      comboDosItems.getNombre());
        assertEquals("combo sin descuento",  comboSinDescuento.getNombre());
        assertEquals("combo gratis",         comboDescuentoTotal.getNombre());
    }
 
    @Test
    void testGetPrecioComboCorral() {
        
        assertEquals(22050, comboCorral.getPrecio());
    }
 
    @Test
    void testGetPrecioComboTodoterreno() {
        
        assertEquals(34317, comboTodoterreno.getPrecio());
    }
 
    @Test
    void testGetPrecioDosItems() {
        
        assertEquals(17765, comboDosItems.getPrecio());
    }
 
    @Test
    void testGetPrecioSinDescuento() {
        
        assertEquals(19500, comboSinDescuento.getPrecio());
    }
 
    @Test
    void testGetPrecioDescuentoTotal() {
       
        assertEquals(0, comboDescuentoTotal.getPrecio());
    }
 
    @Test
    void testGetPrecioUnSoloItem() {
  
        assertEquals(4500, comboUnItem.getPrecio());
    }
 
/// Generar factura
    @Test
    void testGenerarTextoFacturaComboCorral() {
        String esperado = "Combo combo corral\n"
                        + " Descuento: 0.1\n"
                        + "            22050\n";
        assertEquals(esperado, comboCorral.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaComboTodoterreno() {
        String esperado = "Combo combo todoterreno\n"
                        + " Descuento: 0.07\n"
                        + "            34317\n";
        assertEquals(esperado, comboTodoterreno.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaComboDosItems() {
        String esperado = "Combo combo dos items\n"
                        + " Descuento: 0.15\n"
                        + "            17765\n";
        assertEquals(esperado, comboDosItems.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaComboSinDescuento() {
        String esperado = "Combo combo sin descuento\n"
                        + " Descuento: 0.0\n"
                        + "            19500\n";
        assertEquals(esperado, comboSinDescuento.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaComboGratis() {
        String esperado = "Combo combo gratis\n"
                        + " Descuento: 1.0\n"
                        + "            0\n";
        assertEquals(esperado, comboDescuentoTotal.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaComboUnItem() {
        String esperado = "Combo combo gaseosa\n"
                        + " Descuento: 0.1\n"
                        + "            4500\n";
        assertEquals(esperado, comboUnItem.generarTextoFactura());
    }
    
}
 
