package uniandes.dpoo.hamburguesas.tests;
 
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import java.util.ArrayList;
 
public class PedidoTest {
 
    // Utilizo otra vez los ajustables pq no tengo creatividad
    private ProductoMenu corral;        
    private ProductoMenu papasMedianas; 
    private ProductoMenu gaseosa;       
    private Ingrediente queso;               
    private Ingrediente lechuga;        
 
    // Escenarios :D
    private Pedido pedidoVacio;          
    private Pedido pedidoUnProducto;     
    private Pedido pedidoVariosProductos;// ProductoMenu + Combo + ProductoAjustado
    private Pedido pedidoOtroCliente;   
 
    @BeforeEach
    void setUp() {
        corral        = new ProductoMenu("corral",        14000);
        papasMedianas = new ProductoMenu("papas medianas", 5500);
        gaseosa       = new ProductoMenu("gaseosa",        5000);
        queso    = new Ingrediente("queso mozzarella", 2500);
        lechuga  = new Ingrediente("lechuga",          1000);
 
        pedidoVacio         = new Pedido("María García",    "Calle 10 # 5-20");
        pedidoUnProducto    = new Pedido("Carlos López",    "Carrera 7 # 45-30");
        pedidoVariosProductos = new Pedido("Ana Martínez",  "Av. 68 # 12-00");
        pedidoOtroCliente   = new Pedido("Luis Rodríguez",  "Calle 100 # 20-10");
 
    
        pedidoUnProducto.agregarProducto(corral);
 
        ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
        itemsCombo.add(corral);
        itemsCombo.add(papasMedianas);
        Combo combo = new Combo("combo corral", 0.10, itemsCombo);
 
        ProductoAjustado ajustado = new ProductoAjustado(corral);
        ajustado.getAgregados().add(queso);
        ajustado.getEliminados().add(lechuga);
 
        pedidoVariosProductos.agregarProducto(corral);
        pedidoVariosProductos.agregarProducto(combo);
        pedidoVariosProductos.agregarProducto(ajustado);
    }
 
    //Aqui igual dudo de este test
 
    @Test
    void testGetIdPedido_sonConsecutivosYDistintos() {
        int id1 = pedidoVacio.getIdPedido();
        int id2 = pedidoUnProducto.getIdPedido();
        int id3 = pedidoVariosProductos.getIdPedido();
        int id4 = pedidoOtroCliente.getIdPedido();
 
        // Deben ser todos distintos ya que no puedo confirmar si es 1,2 o 3 porque la variable es estatica, quiere decir que no se resetea entre las pruebas. Entonces solo miro que sean difernetes entre sí 
        assertNotEquals(id1, id2);
        assertNotEquals(id2, id3);
        assertNotEquals(id3, id4);
    }
    
    //Aqui medio me copie de combo, testee varios a la vez KJNSDKJNFKJSNDFKJN
 
   
    @Test
    void testGetNombreClienteVariosClientes() {
        assertEquals("María García",    pedidoVacio.getNombreCliente());
        assertEquals("Carlos López",    pedidoUnProducto.getNombreCliente());
        assertEquals("Ana Martínez",    pedidoVariosProductos.getNombreCliente());
        assertEquals("Luis Rodríguez",  pedidoOtroCliente.getNombreCliente());
    }
 
    
 
    @Test
    void testGetPrecioTotalPedidoPedidoVacio() {
        assertEquals(0, pedidoVacio.getPrecioTotalPedido());
    }
 
    @Test
    void testGetPrecioTotalPedidoUnProducto() {
        
        assertEquals(16660, pedidoUnProducto.getPrecioTotalPedido());
    }
 
    @Test
    void testGetPrecioTotalPedidoVariosProductos() {

        assertEquals(57179, pedidoVariosProductos.getPrecioTotalPedido());
    }
 
    //Para producto la verdad es que voy a utilizar la factura de producto ajustado por si acaso 
    //Me costó generar este test KJSDNKJFNKJSDNFKJ
    @Test
    void testGenerarTextoFacturaPedidoVacio() {
        String esperado = "Cliente: María García\n" + "Dirección: Calle 10 # 5-20\n"+ "----------------\n" + "----------------\n"+ "Precio Neto:  0\n" + "IVA:          0\n"  + "Precio Total: 0\n";
        assertEquals(esperado, pedidoVacio.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaPedidoUnProducto() {
        String esperado = "Cliente: Carlos López\n"+ "Dirección: Carrera 7 # 45-30\n" + "----------------\n"+ "corral\n"  + "            14000\n" + "----------------\n" + "Precio Neto:  14000\n" + "IVA:          2660\n" + "Precio Total: 16660\n";
        assertEquals(esperado, pedidoUnProducto.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaPedidoVariosProductos() {
        String esperado = "Cliente: Ana Martínez\n"+ "Dirección: Av. 68 # 12-00\n" + "----------------\n" + "corral\n" + "            14000\n" + "Combo combo corral\n" + " Descuento: 0.1\n" + "            17550\n" + "corral\n" + "            14000\n" + "    +queso mozzarella                2500"+ "    -lechuga" + "            16500\n"+ "----------------\n" + "Precio Neto:  48050\n" + "IVA:          9129\n"+ "Precio Total: 57179\n";
        assertEquals(esperado, pedidoVariosProductos.generarTextoFactura());
    }
    //No genero la factura de Luis, ya que eso sin pedido ya lo teste con Maria. Luis es mas un tipo de pedido que me ayudará con los agregados :D
    
 
 
    @Test
    void testAgregarProductoMenu() {
        pedidoOtroCliente.agregarProducto(corral); // Este lo hago para saber si agregar el producto funciona. Como no retorna nada, entoncces verifico que haya cambiado el precio del pedido, porque se agregó algo
        assertEquals(16660, pedidoOtroCliente.getPrecioTotalPedido());
    }

    @Test
    void testAgregarCombo() {
        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(corral);
        items.add(papasMedianas);
        Combo combo = new Combo("combo Test", 0.10, items);
        pedidoOtroCliente.agregarProducto(combo);
        assertEquals(20884, pedidoOtroCliente.getPrecioTotalPedido());
    }

    @Test
    void testAgregarProductoAjustado() {
        ProductoAjustado aj = new ProductoAjustado(gaseosa);
        aj.getAgregados().add(queso);
        pedidoOtroCliente.agregarProducto(aj);
        assertEquals(8925, pedidoOtroCliente.getPrecioTotalPedido());
    }
    
    
    //No testeamos guardar factura, dado que no sabía como hacerlo, entonces ivan dijo que no tenía que hacerlo :D
}
 
